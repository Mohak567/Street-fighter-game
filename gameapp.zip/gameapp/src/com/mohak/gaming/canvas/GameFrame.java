package com.mohak.gaming.canvas;

import javax.swing.JFrame;

public class GameFrame extends JFrame{
	public GameFrame() {
		setResizable(false);
		setTitle("Street Fighter");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(1400,900);
		setLocationRelativeTo(null);
		Board board = new Board();//board is called
		add(board);//Board is now added in frame
		setVisible(true);
		
	}

	public static void main(String[] args) {
		GameFrame obj =new GameFrame();

	}

}
