package com.mohak.gaming.canvas;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class Board extends JPanel{
	BufferedImage imageBg;
	public Board() {
		loadbackgroundimage();
	}
	@Override
	public void paintComponent(Graphics pen) {//paintcomponent is used to paint/render anything on the image
		printBackgroundImage(pen);
		
	}
	private void printBackgroundImage(Graphics pen) {
		pen.drawImage(imageBg,0,0,1400,900,null);//null is used for image observer because our image size is fixed
	}
	
		private void loadbackgroundimage() {
		try {
			imageBg = ImageIO.read(Board.class.getResource("bg.jpg"));//image source
			}
			catch (Exception ex) {
				System.out.println("Background image failed");
				System.exit(0);
			}
	}
}
